$(document).ready(function () {

    // ACCORDION
    $(".title").click(function () {
        $(".content").not($(this).next()).slideUp();
        $(this).next(".content").slideToggle();
    });


    // FORM SUBMISSION (VALIDATION + AJAX)
    $("#contactForm").submit(function (event) {
        event.preventDefault();

        let name = $("#name").val().trim();
        let email = $("#email").val().trim();

        $("#message").remove();

        // VALIDATION
        if (name === "" || email === "") {
            $("<p id='message'></p>")
                .text("Please fill in all fields!")
                .css("color", "red")
                .appendTo("body");
            return;
        }

        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            $("<p id='message'></p>")
                .text("Please enter a valid email address!")
                .css("color", "red")
                .appendTo("body");
            return;
        }

        // AJAX (simulated)
        $.ajax({
            url: "https://example.com/submit",
            type: "POST",
            data: {
                name: name,
                email: email
            },

            beforeSend: function () {
                console.log("Sending data...");
            },

            success: function () {

                $("body").append("Thank you " + name + ", message received.<br>");

                $("#contactForm").fadeOut(150).fadeIn(150);

                $("#contactForm")[0].reset();
            },

            error: function () {
                console.log("Error submitting form");
            }
        });

    });


    // LIGHTBOX GALLERY
    $(".gallery-img").click(function () {
        let imgSrc = $(this).attr("src");

        $("#lightbox-img").attr("src", imgSrc);
        $("#lightbox").fadeIn();
    });

    $("#lightbox").click(function () {
        $(this).fadeOut();
    });


    // =========================
    // LEAFLET MAP (NEW ADDITION)
    // =========================

    // Create map centered in Soweto (Johannesburg)
    let map = L.map('map').setView([-26.2485, 27.8540], 12);

    // Add map tiles (OpenStreetMap)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Add marker for Hidden Junk
    let marker = L.marker([-26.2485, 27.8540]).addTo(map);

    marker.bindPopup("<b>Hidden Junk Store</b><br>Soweto, Johannesburg").openPopup();


    // =========================
    // DYNAMIC POSTS
    // =========================

    let posts = [
        {
            title: "New Collection Drop",
            text: "We just released fresh streetwear items made in Soweto."
        },
        {
            title: "Weekend Sale",
            text: "Get 20% off selected items this weekend only!"
        },
        {
            title: "Behind the Brand",
            text: "Hidden Junk supports local designers and creatives."
        }
    ];

    let output = "";

    for (let i = 0; i < posts.length; i++) {
        output += `
            <div>
                <h3>${posts[i].title}</h3>
                <p>${posts[i].text}</p>
                <hr>
            </div>
        `;
    }

    $("#postList").html(output);

});