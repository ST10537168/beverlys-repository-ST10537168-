# CHANGELOG

All notable changes to this project will be documented in this file.

This project follows Semantic Versioning.

## [1.0.0] 
### Added
added new colours aliceblue and whitesmoke
- xyz

CHANGED:
created forms with html code
built javascript validation into forms
accodrions was added as one of the elements ans was implemented.
new references like W3schools.



In the html file the pStyle was changed and so was the description.
ccs style- in the header the background color was changed to aliceblue.
        color-was changed to whitesmoke
            list style- was changed to armenian.
README-the Overview was changed.
      mission statement changed.
      Target audience changed.
      Website goals and Objectives changed.
      Timeline and Milestones changed.
- xyz

### Fixed
chose aliceblue over dark blue
chose armenian instead of 'none'
different website goals, around four new goals instead of one.
- xyz

## Semantic Versioning

Format: MAJOR.MINOR.PATCH  
Example: 2.1.3

- MAJOR → Breaking changes (1.0.0 → 2.0.0)  
- MINOR → New features (1.0.0 → 1.1.0)  
- PATCH → Bug fixes / small improvements (1.0.0 → 1.0.1)
