# HIDDEN JUNK
WHEREVER FASHION AND STYLE MERGE..

## Student Information
**Student number:**ST10537168 <br>
**Student Name:** NOXOLO BEVERLY NOBONGWANA 

## Project Overview
Hidden junk is a clothing Brand crafted from exclusive pieces, as a goal to make people feel better while looking better.Our clothing is made from cozy and skin friendly fabric as well as material. Its not just the cost we are focused on but customer satisfaction.
Starting from scratch and sweat to inspire small businesses.

MISSION STATEMENT:Our goal is to deliver elegant , budget friendly and premium clothing that encourages clients to feel self assured and fashionable.Generating stylish and cozy fashion for young adults at reasonable pricing.

A vission statement:With less noise and better trends this business focuses on becoming the go to retail destination for modern,budget
conscious shoppers all around the city.

Target audience:
-Teenagers passionate about fashion.
-Ladies seeking for popular clothes.
-Elegant fashion shoppers.
MISSION STATEMENT:making people feel confident with each style or makeover.

## Website Goals and Objectives
GOALS-enhance customer satisfaction.
     -attract a broader audience.
     -establish trust with clients.
     -boost apparel sales.
OBJECTIVES-introduce a trusted payment system.
          -design an easy to navigate online store with straightforward product information.
          -uncomplicated navigation menu
          -strenghten website loading speed.

## Timeline and Milestones
First Month-business plan developed.
Third Month-webite designed.
Fifth Month-very first product introduced.
Seventh Month-Online store opened.
Nineth Month-customer orders obtained and being shipped.
Twelfth Month-expanding monthly sales.


## Sitemap
![website sitemap](img/mysitemap.png)<br>
img/mysitemap.png





## References
W3Schools tutorials
 W3Schools. HTML Forms Tutorial. https://www.w3schools.com/html/html_forms.asp
 W3Schools. JavaScript Validation. https://www.w3schools.com/js/js_validation.asp

Abrams,Rhonda M,and Eugene Kleiner. The successful business plan:secrets and strategies.The planning shop,2003.
Sahlman,W.A.2008.How to write a great business plan.Harvard Business Press.
Flowerdew,L,2010.Devising and implementing a business proposal module:
Constraints and compromises.English for purpose,29(2),pp.108-120.








